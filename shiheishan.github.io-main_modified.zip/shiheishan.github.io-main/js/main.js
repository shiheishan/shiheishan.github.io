import subjects from '../data/subjects.js';

const preview = document.getElementById('preview');
const progress = document.getElementById('progress');
const dateHeader = document.getElementById('date');

// 日期
const fmt = new Intl.DateTimeFormat('zh-CN', {
  year: 'numeric', month: 'long', day: 'numeric',
  hour: '2-digit', minute: '2-digit', second: '2-digit',
  hour12: false
});
dateHeader.textContent = fmt.format(new Date());

// 渲染列表
let total = 0;
let done = 0;

function render() {
  preview.innerHTML = '';
  Object.entries(subjects).forEach(([subject, tasks]) => {
    const sec = document.createElement('section');
    sec.className = 'subject';
    const h2 = document.createElement('h2');
    h2.textContent = subject;
    sec.appendChild(h2);

    const ul = document.createElement('ul');
    ul.className = 'list';

    tasks.forEach((text, idx) => {
      total++;
      const li = document.createElement('li');
      const id = `${subject}-${idx}`.replace(/\s+/g, '_');

      li.innerHTML = `
        <label class="task">
          <input id="${id}" type="checkbox" />
          <span class="checkbox" aria-hidden="true"></span>
          <span class="label-text">${text}</span>
        </label>
      `;

      const input = li.querySelector('input');
      input.addEventListener('change', () => {
        done += input.checked ? 1 : -1;
        updateProgress();
      });

      ul.appendChild(li);
    });

    sec.appendChild(ul);
    preview.appendChild(sec);
  });
}

function buildProgress() {
  progress.innerHTML = `
    <svg viewBox="0 0 36 36" role="img" aria-label="完成进度">
      <path class="bg" d="M18 2
        a 16 16 0 0 1 0 32
        a 16 16 0 0 1 0 -32" />
      <path class="meter" stroke-dasharray="0,100" d="M18 2
        a 16 16 0 0 1 0 32
        a 16 16 0 0 1 0 -32" />
      <text x="18" y="20" class="percentage">0%</text>
    </svg>
  `;
}

function updateProgress() {
  const meter = progress.querySelector('.meter');
  const text = progress.querySelector('.percentage');
  const percent = total ? Math.round((done / total) * 100) : 0;
  meter.setAttribute('stroke-dasharray', `${percent},100`);
  text.textContent = `${percent}%`;
}

// 初始化
buildProgress();
render();
updateProgress();
